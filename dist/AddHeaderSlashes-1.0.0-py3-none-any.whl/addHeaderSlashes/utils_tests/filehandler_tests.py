import unittest
from addHeaderSlashes.utils.filehandler import browse_for_files


class TestFileBrowsing(unittest.TestCase):
    def test_browse_for_files(self):
        expected_file = "/path/to/expected/file.jsonc"  # Simulated expected file path
        selected_file = browse_for_files()
        self.assertEqual(selected_file, expected_file)


if __name__ == '__main__':
    unittest.main()
