
# Add Header Slashes

Fills in my section headers ASCII art with slashes


## Features

- Import jsonc file
- Preview changes
- Save or discard


## Installation

Install my-project with python

```bash
  python -m build
  python -m pip install .
```
    
## Usage/Examples

```javascript
import Component from 'my-project'

function App() {
  return <Component />
}
```

